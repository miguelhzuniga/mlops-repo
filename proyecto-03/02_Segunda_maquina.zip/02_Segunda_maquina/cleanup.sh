#!/bin/bash

# cleanup-node.sh - Limpia completamente el nodo de recursos MLOps usando sudo

NAMESPACE="mlops-project"
NODE_NAME=$(hostname | tr '[:upper:]' '[:lower:]')

# Colores
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${YELLOW}Iniciando limpieza del nodo '${NODE_NAME}'...${NC}"

# 1. Eliminar deployments y servicios reales
echo -e "${YELLOW}Eliminando Deployments y Services...${NC}"
sudo microk8s kubectl delete deployment fastapi-diabetes -n ${NAMESPACE} --ignore-not-found
sudo microk8s kubectl delete deployment streamlit-diabetes -n ${NAMESPACE} --ignore-not-found
sudo microk8s kubectl delete service fastapi-diabetes -n ${NAMESPACE} --ignore-not-found
sudo microk8s kubectl delete service streamlit-diabetes -n ${NAMESPACE} --ignore-not-found

# 2. Quitar etiquetas del nodo
echo -e "${YELLOW}Eliminando etiquetas del nodo...${NC}"
sudo microk8s kubectl label node ${NODE_NAME} node-type- node-id- --overwrite 2>/dev/null || true

# 3. Eliminar carpeta local de manifiestos si existe
if [ -d "manifests-local" ]; then
  echo -e "${YELLOW}Eliminando carpeta de manifiestos locales...${NC}"
  rm -rf manifests-local
fi

# 4. Eliminar imágenes Docker locales
echo -e "${YELLOW}Eliminando imágenes Docker locales...${NC}"

IMAGES_TO_DELETE=(
  "camilosvel/fastapi-diabetes:latest"
  "camilosvel/streamlit-diabetes:latest"
)

for image in "${IMAGES_TO_DELETE[@]}"; do
  if sudo docker images --format "{{.Repository}}:{{.Tag}}" | grep -q "^${image}$"; then
    echo -e "${YELLOW} - Eliminando imagen ${image}${NC}"
    sudo docker rmi -f "${image}" >/dev/null 2>&1 && \
      echo -e "${GREEN}   ✔ Imagen eliminada: ${image}${NC}" || \
      echo -e "${RED}   ✖ No se pudo eliminar: ${image}${NC}"
  else
    echo -e "${YELLOW}   ⚠ Imagen no encontrada localmente: ${image}${NC}"
  fi
done


echo -e "${GREEN}✅ Limpieza completa realizada para el nodo '${NODE_NAME}' en namespace '${NAMESPACE}'${NC}"
